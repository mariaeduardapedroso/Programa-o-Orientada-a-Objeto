package aula2911;

import javax.swing.JOptionPane;

public class Principal {

    public void iniciar() {
        String string1 = JOptionPane.showInputDialog("Digite o valor 1: ");
        String string2 = JOptionPane.showInputDialog("Informe o valor 2: ");

        Float n1 = Float.parseFloat(string1);
        Float n2 = Float.parseFloat(string2);

        JOptionPane.showMessageDialog(null, "Soma: " + (n1 + n2), "Resultado", JOptionPane.INFORMATION_MESSAGE);

    }

    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.iniciar();
    }

}
