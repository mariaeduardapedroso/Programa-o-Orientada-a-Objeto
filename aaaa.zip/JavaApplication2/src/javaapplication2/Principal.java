package javaapplication2;

import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

/**
 *
 * @author a2150573
 */
public class Principal {

    public void iniciar() {

        InterdaceGrafica gui = InterdaceGrafica.iniciar();
        gui.setSize(200, 300);
        gui.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        gui.setVisible(true);

        JLabel rotulo1 = gui.getRotulo1();

        rotulo1.addMouseListener(new MouseAdapter() {
            public void MouseEntered(MouseEvent e) {
                Toolkit.getDefaultToolkit().beep();
            }
        }
        ); //INTERFACE 
        
        rotulo1.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                System.out.println(rotulo1.getText());
            } 
            
            
        });

    }

    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.iniciar();
    }

}
