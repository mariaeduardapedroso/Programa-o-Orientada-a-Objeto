package ex7;

public class ExceptionB extends ExceptionA{

	public ExceptionB() {
		super("\n ERRO - Exception B = 0! " );
	}
	
	public ExceptionB(String m){
		super(m);
	}
	
}//ExeptionB
