package ex2;

public abstract class MembroUniversidade {
	
	public float salario;
	
	public MembroUniversidade(float s) {
		this.salario = s;
	}

	public abstract void pagamento();

}
