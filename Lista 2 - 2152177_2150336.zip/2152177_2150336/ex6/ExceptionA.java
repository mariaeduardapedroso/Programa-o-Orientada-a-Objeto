package ex6;

public class ExceptionA extends Exception {
    public ExceptionA(String mensagem){
        super(mensagem);
    }

}
