/*
Exercicio 6
Autor(es): Ruan Mateus Trizotti e Maria Eduarda Pedroso
Data: 15/10/2022
*/
package ex6;

import java.util.Scanner;

public class Principal {

    public void iniciar() {
        try {
            Scanner entrada = new Scanner(System.in);
            int numero = entrada.nextInt();

            if (numero == 0) {
                throw new ExceptionA("A");
            } else if (numero == 1) {
                throw new ExceptionB("B");
            } else {
                throw new ExceptionC("C");
            }

        } catch (ExceptionA e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.iniciar();
    }

}
