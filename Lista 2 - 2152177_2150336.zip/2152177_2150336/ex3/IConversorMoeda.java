package ex3;

public interface IConversorMoeda {

	public abstract float getConversaoDolar();
}
