package ex1;

public class Animal {
	
	public String nome;
	
	public Animal(String nome) {
		this.nome = nome;
	}


}
