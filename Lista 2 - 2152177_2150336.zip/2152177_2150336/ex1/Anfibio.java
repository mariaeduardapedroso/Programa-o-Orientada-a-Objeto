package ex1;

public class Anfibio extends Animal {
	
	protected String quantidadedeEscamas;
	
	public Anfibio(String nome, String quantidade) {
		super(nome);
		this.quantidadedeEscamas = quantidade;
	}

}
