/*
Exercicio 4
Autor(es): Ruan Mateus Trizotti e Maria Eduarda Pedroso
Data: 15/10/2022
*/
package ex4;

import java.util.ArrayList;

public class Principal {

	public static void main(String[] args) {
		ArrayList<Empregado> lista = new ArrayList<>();
		lista.add(new Bonificado("madu","pedroso",1000.0f,200.0f,333.0f));
		lista.add(new Comissionado("ruan","mateus",1000.0f,0.05f,10000.0f));
		lista.add(new Horista("isadora","bolitini",2000.0f,10,100.0f));
		
		for(Empregado item:lista) {
			item.ganhos();
			item.imprimir();
		}
	}

}
