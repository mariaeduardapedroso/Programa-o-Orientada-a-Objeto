package trabalho.m;

public class TrabalhoM {
	public static void main(String[] args) {
		Recepcao hospital = new Recepcao();
		hospital.start();
	}
}