package trabalho.m;

public class SetorEmergencia extends Setor {
	public SetorEmergencia(){
		super();
	}
}