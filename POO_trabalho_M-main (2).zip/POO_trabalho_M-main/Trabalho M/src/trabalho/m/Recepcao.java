package trabalho.m;

public class Recepcao {
	public void start(){
		JFrame tela = new JFrame();
		tela.main();
	}
}
