package trabalho.m;

import java.util.Date;

public class SetorPediatrico extends Setor {
	public SetorPediatrico(){
		super();
	}
}