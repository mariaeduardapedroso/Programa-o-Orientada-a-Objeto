package trabalho.m;

public class SetorOrtopedia extends Setor {
	public SetorOrtopedia(){
		super();
	}
}