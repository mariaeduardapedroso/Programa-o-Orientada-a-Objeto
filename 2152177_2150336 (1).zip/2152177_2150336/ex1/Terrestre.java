package ex1;

public class Terrestre extends Animal {
	
	protected String quantidadedePelos;
	
	public Terrestre(String nome, String quantidade) {
		super(nome);
		this.quantidadedePelos = quantidade;
	}

}
