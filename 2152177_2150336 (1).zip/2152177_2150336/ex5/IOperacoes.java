package ex5;

public interface IOperacoes {
	
	public void setOperando1(float Operando1);
	public void setOperando2(float Operando2);
	public float getResultado();
	public String getNome();
	public int getQuantidade();

	
	
}
