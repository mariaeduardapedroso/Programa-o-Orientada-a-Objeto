package ex6;


public class ExceptionB extends ExceptionA {
    public ExceptionB(String mensagem){
        super(mensagem);
    }
}
