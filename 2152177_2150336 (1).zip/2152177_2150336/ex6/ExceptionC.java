package ex6;


public class ExceptionC extends ExceptionB{
    public ExceptionC(String mensagem){
        super(mensagem);
    }
}
